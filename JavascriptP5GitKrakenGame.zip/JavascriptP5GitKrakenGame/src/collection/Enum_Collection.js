/*==================================================*/
var Branch_Enum = {

    MASTER_BRANCH   : "MASTER_BRANCH",
    _1_BRANCH       : "_1_BRANCH",
    _2_BRANCH       : "_2_BRANCH",
    _3_BRANCH       : "_3_BRANCH",
    _4_BRANCH       : "_4_BRANCH"

};
/*==================================================*/